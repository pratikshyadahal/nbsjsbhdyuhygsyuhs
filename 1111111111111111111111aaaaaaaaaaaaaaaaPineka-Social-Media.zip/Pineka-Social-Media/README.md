# Pineka-Social-Media
  
 <a href="https://play.google.com/store/apps/details?id=com.wisnusaputra.pinekaapp"><img class="irc_mi" src="https://play.google.com/intl/en_us/badges/images/generic/en_badge_web_generic.png" width="304" height="118"></a>
  
  Pineka is app for Android simillar with Instagram. This app interated with Firebase.
 # Feature
 1. View Posts
 2. View Story
 3. Add Firiend or Follow
 4. Add Story
 5. Edit Profile
 6. Notification
 7. Add Post
 8. Game 4 Categories
 9. etc.
 
 
 
 ## setup this project
 1. clone this project
 ```
 https://github.com/SaputraGo/Pineka-Social-Media.git
 ```
 or
 
 ```
 git@github.com:SaputraGo/Pineka-Social-Media.git
 ```
 
 2. Open Android Studio
 3. Import this Project to Android Studio
 4. Login Firebase and create new Project
 5. Download ```google-services.json``` and paste to Android project/ app 
 6. Enable Authtentication email sign-In, datebase, storage
 
 
 ## Screenshot

Landing | Home | All User | Notification | Profile | Post 
--- | --- | --- |--- |--- |--- 
![landing](https://github.com/SaputraGo/Pineka-Social-Media/blob/master/screenshot/Screenshot_20190529-081357.png) | ![Home](https://github.com/SaputraGo/Pineka-Social-Media/blob/master/screenshot/Screenshot_20190528-114222.png) | ![All User](https://github.com/SaputraGo/Pineka-Social-Media/blob/master/screenshot/Screenshot_20190528-114229.png) | ![Notification](https://github.com/SaputraGo/Pineka-Social-Media/blob/master/screenshot/Screenshot_20190528-114248.png) | ![Profile](https://github.com/SaputraGo/Pineka-Social-Media/blob/master/screenshot/Screenshot_20190528-114301.png) | ![Post](https://github.com/SaputraGo/Pineka-Social-Media/blob/master/screenshot/Screenshot_20190528-114356.png) 

 
Please follow and Contribution

[Facebook](https://www.facebook.com/wisnusaputradev)
[Twitter](https://twitter.com/WisnuSaputraDev)
[Instagram](https://www.instagram.com/wisnu_saputrakey)
