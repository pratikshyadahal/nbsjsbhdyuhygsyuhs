package com.wisnusaputra.pinekaapp.Activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.ramotion.paperonboarding.PaperOnboardingEngine;
import com.ramotion.paperonboarding.PaperOnboardingPage;
import com.ramotion.paperonboarding.listeners.PaperOnboardingOnChangeListener;
import com.ramotion.paperonboarding.listeners.PaperOnboardingOnRightOutListener;
import com.wisnusaputra.pinekaapp.R;

import java.util.ArrayList;

public class IntroActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.onboarding_main_layout);

//        if (android.os.Build.VERSION.SDK_INT <= Build.VERSION_CODES.M) {
//            startActivity(new Intent(this, LoginActivity.class));
//            finish();
//        }

        if (restorePref()){
            startActivity(new Intent(this, StartActivity.class));
            finish();

        }

        PaperOnboardingEngine engine = new PaperOnboardingEngine(findViewById(R.id.onboardingRootView), getDataForOnboarding(), getApplicationContext());

        engine.setOnChangeListener(new PaperOnboardingOnChangeListener() {
            @Override
            public void onPageChanged(int oldElementIndex, int newElementIndex) {

            }
        });

        engine.setOnRightOutListener(new PaperOnboardingOnRightOutListener() {
            @Override
            public void onRightOut() {
                // Probably here will be your exit action
                startActivity(new Intent(IntroActivity.this, StartActivity.class));
                finish();
            }
        });

        savePref();

    }


    // Just example data for Onboarding
    private ArrayList<PaperOnboardingPage> getDataForOnboarding() {
        // prepare data
        PaperOnboardingPage scr1 = new PaperOnboardingPage("Social App", "Best Social Platform",
                Color.parseColor("#46A7F9"), R.drawable.logo, R.drawable.skip);
        PaperOnboardingPage scr2 = new PaperOnboardingPage("Make Friends WorldWide", "Follow and Make friends online With This Platform",
                Color.parseColor("#ED3F5B"), R.drawable.friend, R.drawable.skip);
        PaperOnboardingPage scr3 = new PaperOnboardingPage("Share Your Art", "Show your art and make worldwide",
                Color.parseColor("#FDC730"), R.drawable.share, R.drawable.skip);

        ArrayList<PaperOnboardingPage> elements = new ArrayList<>();
        elements.add(scr1);
        elements.add(scr2);
        elements.add(scr3);
        return elements;
    }

    private boolean restorePref() {
        SharedPreferences pref= getApplicationContext().getSharedPreferences("myPref", MODE_PRIVATE);
        Boolean isbeforeIntro = pref.getBoolean("introOPen", false);
        return isbeforeIntro;
    }

    private void savePref(){
        SharedPreferences sharedPref = getApplicationContext().getSharedPreferences("myPref",MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putBoolean("introOPen", true);
        editor.commit();
    }

}
